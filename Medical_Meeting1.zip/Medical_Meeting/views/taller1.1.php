<?php
require_once '../assets/conexion/servidor.php';
$conexion->query("SET NAMES 'utf8'");
$conexion = connect($host, $port, $db_name, $db_username, $db_password);
$query =$conexion->prepare("SELECT * FROM mostrar_cita;");

$query->execute();
$resultado =$query->fetchAll();


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Oasis</title>
</header>


<link rel="stylesheet" href="../assets/css/estilo_taller1.1.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<?php include 'header_taller.php'; ?>

</head>
<body>
    


<div class="fondo">

<h1 class="titulo_taller">Citas registradas</h1>

<table class="table-responsive">
    <thead>
<tr class="fila_principal">
    <td>Nombre del Especialista</td>
    <td>Nombre de Especialidad</td>
    <td>Turno</td>
    <td>Dia</td>
    <td>Hora</td>
    <td>Reservación</td>
</tr>
</thead>
<?php  foreach($resultado as $taller):  ?>

    <!--taller1.2.php?idtaller='<?php //echo $taller['NombreTaller']?>'-->

<tr class="filas_secundarias" id="color_gris" >
    <td> <a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"> <?php echo utf8_encode($taller['NombreEspecialista']);?> </a></td>
    <td> <a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"> <?php echo utf8_encode($taller['NombreEspecialidad']);?></a></td>
    <!--<td><a href="taller1.2.php?tallerista=<?php //echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php //echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php //echo $taller['Calendario']?>&turno=<?php //echo $taller['Turno']?>&dia=<?php //echo $taller['Dia']?>"><?php //echo $taller['Calendario']?></a></td>-->
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Turno']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Dia']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Hora']?></a></td>

</tr>
</a>

<?php   endforeach; ?>

</table>

</div>

<script src="../assets/js/jquery-3.6.0.min.js"></script>

</body>
</html>
<?php $conexion = null;?>